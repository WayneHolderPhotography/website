</div> <!-- End #wrapper -->
<!-- Start Footer -->
<div class="footer">
    <div class="page">
        <div class="">
            <div id="text-3" class="small-12 large-3 footer-section">
                <div class="textwidget">
                    <ul class="creted">
                        <?php dynamic_sidebar( 'footer-logo-section' ); ?>
                    </ul>
                </div>
            </div>

            <div id="text-3" class="small-12 large-3 footer-section">
                <div class="textwidget">
                    <ul class="creted">
                        <?php dynamic_sidebar( 'footer-userfull-links' ); ?>
                    </ul>
                </div>
            </div>

            <div id="text-3" class="small-12 large-3 footer-section">
                <div class="textwidget">
                    <ul class="creted">
                        <?php dynamic_sidebar( 'footer-blog' ); ?>
                    </ul>
                </div>
            </div>

            <div id="text-3" class="small-12 large-3 footer-section">
                <div class="textwidget">
                    <ul class="creted">
                        <?php dynamic_sidebar( 'footer-map-section' ); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div><!-- End Footer -->

<?php wp_footer(); ?>
</body>
</html>